class Constants:

    ita_job_posts_needed_columns = ["jobTitle", "jobDescription"]
    ita_job_posts_filename = "ita_job_posts.csv"
    EXPERIS_LOGO = "http://health5g.eu/wp-content/uploads/2019/09/Experis-IT.png"
    MAX_N_OF_RECOMMENDATIONS_SHOWN = 4